"""Build docs/final_report.docx and docs/final_presentation.pptx from this repository's real results.

    python scripts/build_docs.py

Reads models/frozen_config.json, outputs/metrics.json, tables/*.csv, figures/*.png, docs/limitation_list.md and (optionally)
docs/text_overrides.json (keys: abstract, future_scope, conclusion, dataset_source, github_url).
"""
import datetime
import json
import os
import re
import textwrap

import pandas as pd

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
P = lambda *a: os.path.join(ROOT, *a)
exists = os.path.exists
AUTHOR = "Vuda Jaya Sai Ganesh"
TITLE = "Battery State-of-Charge and Remaining Charge-Time Estimation from Li-ion Drive-Cycle Data"

cfg = json.load(open(P("models", "frozen_config.json")))
met = json.load(open(P("outputs", "metrics.json")))
ov = json.load(open(P("docs", "text_overrides.json"))) if exists(P("docs", "text_overrides.json")) else {}
soc, ch = met["soc"], met.get("charge")
label = cfg["chosen_model"]
n_tr, n_te = cfg["train_shape"][0], cfg["test_shape"][0]
f_tr, f_te = len(cfg["train_file_ids"]), len(cfg["test_file_ids"])


def tab(name, **kw):
    return pd.read_csv(P("tables", name), **kw) if exists(P("tables", name)) else None


def fig(name):
    return P("figures", name) if exists(P("figures", name)) else None


def short(t, n=150):
    return textwrap.shorten(re.sub(r"\*\*|`", "", t), n, placeholder="...")


sel, vs, perf_hist = tab("selection_table_soc.csv"), tab("final_vs_baselines_soc.csv"), tab("day18_full_comparison.csv")
by_band, by_file = tab("error_by_SOC_band.csv"), tab("error_by_file_id.csv")
lim = []
if exists(P("docs", "limitation_list.md")):
    lim = [re.sub(r"^\d+\.\s*", "", l.strip()) for l in open(P("docs", "limitation_list.md")) if re.match(r"^\d+\.", l.strip())]
base = None
if vs is not None and "Mean baseline" in vs["model"].values:
    others = vs[~vs["model"].isin(["Mean baseline", label + " (final)"])]
    base = others.sort_values("MAE").iloc[0] if len(others) else None

abstract = ov.get("abstract") or (
    f"This project estimates the state of charge (SOC) of a Li-ion cell from voltage, current, cell temperature, power and ambient temperature, "
    f"and the remaining charging time inside charging segments. The frozen dataset has {n_tr + n_te:,} rows; a file-grouped split keeps "
    f"{f_tr} files for training and {f_te} files for held-out testing so that time-correlated rows never leak between the two. "
    f"Candidates were compared with grouped cross-validation on the training files and the final model ({label}) was chosen with a rule fixed before "
    f"the test set was opened. On the held-out files it reaches MAE {soc['MAE']:.2f} %, RMSE {soc['RMSE']:.2f} % and R2 {soc['R2']:.3f}"
    + (f", compared with MAE {base['MAE']:.2f} % for {base['model']}" if base is not None else "")
    + (f". Remaining charge time reaches MAE {ch['MAE']:.0f} s on {ch['n_files']} charging file(s) and is indicative only" if ch else "")
    + ". The complete pipeline is packaged, tested and reproducible from the command line.")
future = ov.get("future_scope") or [
    "Investigate why the history-based engineered features failed to beat raw features and repair them.",
    "Add sequence-aware models (windowed features, GRU / LSTM) and compare them under the same grouped protocol.",
    "Collect data at more ambient temperatures and drive cycles; use leave-one-temperature-out validation.",
    "Add uncertainty estimates and an out-of-range input detector so unreliable predictions are flagged.",
    "Collect more charging segments before treating charge time as a production deliverable.",
    "Extend to other cells / chemistries and to ageing (state of health) effects."]
conclusion = ov.get("conclusion") or (
    f"A frozen, reproducible pipeline estimates SOC with MAE {soc['MAE']:.2f} % on unseen files"
    + (f", {100 * (base['MAE'] - soc['MAE']) / base['MAE']:.0f} % lower than {base['model']}" if base is not None and base["MAE"] > soc["MAE"] else "")
    + ". The main risks are the small number of held-out files, the static (history-free) framing and untested conditions; "
      "they are documented with concrete failure conditions and a future-work plan.")
dataset_source = ov.get("dataset_source", "Li-ion drive-cycle dataset (source / citation to be added via docs/text_overrides.json)")
github_url = ov.get("github_url", "(repository URL to be added via docs/text_overrides.json)")


def build_report():
    from docx import Document
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    from docx.shared import Inches, Pt
    doc = Document()
    doc.styles["Normal"].font.name = "Calibri"
    doc.styles["Normal"].font.size = Pt(11)
    doc.add_heading(TITLE, 0)
    doc.add_paragraph(f"{AUTHOR}  |  Individual project report  |  {datetime.date.today():%d %B %Y}")

    def add_df(df, decimals=3, caption=None):
        df = df.copy()
        for c in df.columns:
            if pd.api.types.is_float_dtype(df[c]):
                df[c] = df[c].map(lambda v: f"{v:.{decimals}f}")
        tb = doc.add_table(rows=1, cols=len(df.columns))
        tb.style = "Light Grid Accent 1"
        for j, c in enumerate(df.columns):
            tb.rows[0].cells[j].text = str(c)
        for _, r in df.iterrows():
            cells = tb.add_row().cells
            for j, v in enumerate(r):
                cells[j].text = str(v)
        for row in tb.rows:
            for c in row.cells:
                for p in c.paragraphs:
                    for run in p.runs:
                        run.font.size = Pt(9)
        if caption:
            p = doc.add_paragraph(caption)
            p.runs[0].italic = True

    def add_fig(name, caption, width=6.2):
        f = fig(name)
        if f:
            doc.add_picture(f, width=Inches(width))
            doc.paragraphs[-1].alignment = WD_ALIGN_PARAGRAPH.CENTER
            p = doc.add_paragraph(caption)
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            p.runs[0].italic = True

    doc.add_heading("Abstract", 1)
    doc.add_paragraph(abstract)
    doc.add_heading("1. Introduction and objectives", 1)
    doc.add_paragraph("State of charge (SOC) tells a battery-management system how much usable energy remains, but it cannot be measured directly. "
                      "This project builds data-driven estimators for (i) SOC in percent and (ii) the remaining time until a charging segment ends, "
                      "following a strict protocol: a frozen file-grouped split, validation-only model selection, a single scoring of the held-out files "
                      "and a reproducible software package.")
    for b in ["Estimate SOC from voltage, current, cell temperature, power and ambient temperature.",
              "Estimate remaining charging time inside constant-current / constant-voltage (CC-CV) charge segments.",
              "Select the final method from validation evidence, robustness and appropriate simplicity.",
              "Deliver a frozen, documented and reproducible software package."]:
        doc.add_paragraph(b, style="List Bullet")
    doc.add_heading("2. Data", 1)
    doc.add_paragraph(f"Source: {dataset_source}. The frozen split contains {n_tr + n_te:,} rows in {f_tr + f_te} files. Features: {', '.join(cfg['features'])}. "
                      f"Target: {cfg['target']} (SOC, %). The charging target {'remaining_charge_time_s'} is the time from each row to the end of its contiguous CHA segment.")
    doc.add_paragraph(f"Frozen split: {cfg['split']}. Training: {f_tr} files / {n_tr:,} rows; held-out: {f_te} files / {n_te:,} rows. "
                      "Rows from one file are strongly correlated in time, so splitting by file (not by row) is essential to avoid optimistic estimates.")
    doc.add_heading("3. Methodology", 1)
    for b in [f"Preprocessing: {cfg['preprocessing']}.", "Candidates: mean baseline, linear regression, random forest, histogram gradient boosting (an MLP was tried in Week 3 and rejected).",
              f"Selection: {cfg['selection_rule']}.", f"Metrics: {', '.join(cfg['metrics'])}, plus worst-file MAE and 95th-percentile absolute error; the held-out set is used for the final score only.",
              "Post-processing: SOC predictions are clipped to 0-100 %."]:
        doc.add_paragraph(b, style="List Bullet")
    if perf_hist is not None:
        doc.add_heading("3.1 Experiment history (Week 3, Day 18)", 2)
        add_df(perf_hist, 3, "Table 1. Methods scored during exploration. Engineered features did not help.")
    doc.add_heading("4. Results", 1)
    if sel is not None:
        doc.add_heading("4.1 Model selection (grouped cross-validation, training files only)", 2)
        add_df(sel, 3, "Table 2. Selection evidence from Day 22.")
    add_fig("fig_cv_selection.png", "Figure 1. Cross-validated MAE of the candidate models (training files only).", 5.5)
    doc.add_heading("4.2 Final SOC model on held-out files", 2)
    if vs is not None:
        add_df(vs, 3, "Table 3. Final model versus baselines (held-out files).")
    doc.add_paragraph(f"The frozen {label} reaches MAE {soc['MAE']:.3f} %, RMSE {soc['RMSE']:.3f} % and R2 {soc['R2']:.4f}; the worst single file has MAE "
                      f"{soc['worst_file_MAE']:.2f} % and the 95th-percentile absolute error is {soc['p95_abs_error']:.2f} %.")
    add_fig("fig_pred_vs_actual.png", "Figure 2. Held-out SOC: predicted vs actual, residuals and per-file MAE.")
    if ch:
        doc.add_heading("4.3 Remaining charging time", 2)
        doc.add_paragraph(f"MAE {ch['MAE']:.1f} s, RMSE {ch['RMSE']:.1f} s, R2 {ch['R2']:.3f} on {ch['n_rows']} held-out charging rows from {ch['n_files']} file(s). "
                          "Few files contain charging, so this result is indicative rather than definitive.")
        add_fig("fig_charge_pred_vs_actual.png", "Figure 3. Remaining charge time: predicted vs actual.", 4.8)
    doc.add_heading("5. Error and failure analysis", 1)
    add_fig("fig_error_by_soc_band.png", "Figure 4. MAE by SOC band (dashed line = overall MAE).", 5.5)
    add_fig("fig_worst_file_trace.png", "Figure 5. Predicted vs actual SOC for the worst held-out file.")
    add_fig("fig_feature_importance.png", "Figure 6. Permutation importance of the input features.", 5.5)
    if by_file is not None:
        add_df(by_file, 3, "Table 4. Error per held-out file.")
    doc.add_heading("5.1 Limitations and likely failure conditions", 2)
    for l in lim:
        doc.add_paragraph(re.sub(r"\*\*", "", l), style="List Bullet")
    doc.add_heading("6. Reproducibility and software package", 1)
    doc.add_paragraph(f"Repository: {github_url}. The package has the pipeline module, command-line scripts (train / evaluate / predict), the frozen models and "
                      "configuration, tests, example input/output, figures, tables and this report generator. Retraining from the frozen configuration "
                      "(same estimator, hyper-parameters and seed) is checked against the stored model.")
    doc.add_paragraph("python scripts/predict.py --model-dir models --input data/sample_input.csv --output outputs/sample_output.csv", style="Intense Quote")
    doc.add_heading("7. Future scope", 1)
    for f in future:
        doc.add_paragraph(f, style="List Bullet")
    doc.add_heading("8. Conclusion", 1)
    doc.add_paragraph(conclusion)
    os.makedirs(P("docs"), exist_ok=True)
    doc.save(P("docs", "final_report.docx"))
    print("wrote docs/final_report.docx")


def build_ppt():
    from PIL import Image
    from pptx import Presentation
    from pptx.dml.color import RGBColor
    from pptx.enum.shapes import MSO_SHAPE
    from pptx.util import Inches, Pt
    NAVY = RGBColor(0x1F, 0x2A, 0x44)
    prs = Presentation()
    prs.slide_width, prs.slide_height = Inches(13.333), Inches(7.5)
    blank = prs.slide_layouts[6]

    def slide(title, notes=""):
        s = prs.slides.add_slide(blank)
        bar = s.shapes.add_shape(MSO_SHAPE.RECTANGLE, 0, 0, prs.slide_width, Inches(1.0))
        bar.fill.solid()
        bar.fill.fore_color.rgb = NAVY
        bar.line.fill.background()
        tf = s.shapes.add_textbox(Inches(.5), Inches(.15), Inches(12.3), Inches(.75)).text_frame
        tf.word_wrap = True
        tf.text = title
        p = tf.paragraphs[0]
        p.font.size, p.font.bold, p.font.color.rgb = Pt(28), True, RGBColor(255, 255, 255)
        s.notes_slide.notes_text_frame.text = notes
        return s

    def bullets(s, items, x, y, w, h, size=16):
        tf = s.shapes.add_textbox(Inches(x), Inches(y), Inches(w), Inches(h)).text_frame
        tf.word_wrap = True
        for i, it in enumerate(items):
            p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
            p.text = "• " + it
            p.font.size, p.space_after = Pt(size), Pt(8)

    def pic(s, name, x, y, w, h):
        f = fig(name)
        if not f:
            return
        iw, ih = Image.open(f).size
        k = min(w / iw, h / ih)
        s.shapes.add_picture(f, Inches(x + (w - iw * k) / 2), Inches(y + (h - ih * k) / 2), Inches(iw * k), Inches(ih * k))

    def tbl(s, df, x, y, w, h, size=11):
        df = df.copy()
        for c in df.columns:
            if pd.api.types.is_float_dtype(df[c]):
                df[c] = df[c].map(lambda v: f"{v:.3f}")
        t = s.shapes.add_table(len(df) + 1, len(df.columns), Inches(x), Inches(y), Inches(w), Inches(h)).table
        for j, c in enumerate(df.columns):
            t.cell(0, j).text = str(c)
        for i, (_, r) in enumerate(df.iterrows(), 1):
            for j, v in enumerate(r):
                t.cell(i, j).text = str(v)
        for row in t.rows:
            for c in row.cells:
                for p in c.text_frame.paragraphs:
                    p.font.size = Pt(size)

    s = prs.slides.add_slide(blank)
    bg = s.shapes.add_shape(MSO_SHAPE.RECTANGLE, 0, 0, prs.slide_width, prs.slide_height)
    bg.fill.solid()
    bg.fill.fore_color.rgb = NAVY
    bg.line.fill.background()
    tf = s.shapes.add_textbox(Inches(.8), Inches(2.3), Inches(11.7), Inches(2.5)).text_frame
    tf.word_wrap = True
    tf.text = TITLE
    tf.paragraphs[0].font.size, tf.paragraphs[0].font.bold, tf.paragraphs[0].font.color.rgb = Pt(36), True, RGBColor(255, 255, 255)
    p = tf.add_paragraph()
    p.text = f"{AUTHOR}  |  Individual project  |  {datetime.date.today():%B %Y}"
    p.font.size, p.font.color.rgb = Pt(18), RGBColor(0xBE, 0xD3, 0xEC)

    s = slide("Problem and objectives", "[1:00] Why SOC matters and what is delivered.")
    bullets(s, ["SOC cannot be measured directly - it must be estimated from voltage, current and temperature",
                "Goal 1: estimate SOC (%)", "Goal 2: estimate remaining charging time in CC-CV charge segments",
                "Goal 3: choose the final method on validation evidence, robustness and simplicity", "Goal 4: deliver a frozen, reproducible software package"], .6, 1.4, 12, 5)

    s = slide("Data and frozen split", "[1:00] Stress that the split is by file, because rows within a file are correlated.")
    bullets(s, [f"{n_tr + n_te:,} rows in {f_tr + f_te} files", f"Features: {', '.join(cfg['features'])}",
                f"Split by file_id: {f_tr} train / {f_te} held-out files - no leakage", "Split frozen; held-out files used for the final score only",
                "Charging target = seconds to the end of each CHA segment"], .6, 1.4, 12, 5)

    s = slide("Methodology", "[1:00] Walk the pipeline left to right; stress the pre-agreed rule.")
    bullets(s, ["Candidates: mean, linear, random forest, histogram gradient boosting (MLP rejected)", "Grouped cross-validation on training files only",
                short("Selection: " + cfg["selection_rule"], 160), "Metrics: MAE, RMSE, R2, worst-file MAE, p95 error; SOC clipped to 0-100 %",
                "Engineered features excluded - they did not beat raw features"], .6, 1.4, 12, 5)

    s = slide("Model selection evidence", "[1:00] Why the chosen model won.")
    if sel is not None:
        tbl(s, sel, .6, 1.5, 12.1, 2.4, 12)
    pic(s, "fig_cv_selection.png", .6, 4.1, 12.1, 3.2)

    s = slide("Final results on held-out files", "[1:30] Quote the headline numbers and compare with the baselines.")
    if vs is not None:
        tbl(s, vs, .5, 1.4, 6.2, 2.0, 11)
    bullets(s, [f"SOC: MAE {soc['MAE']:.2f} %, RMSE {soc['RMSE']:.2f} %, R2 {soc['R2']:.3f}", f"Worst file MAE {soc['worst_file_MAE']:.2f} %; p95 |err| {soc['p95_abs_error']:.2f} %"]
            + ([f"Charge time: MAE {ch['MAE']:.0f} s, R2 {ch['R2']:.2f} ({ch['n_files']} file(s) - indicative)"] if ch else []), .5, 3.7, 6.2, 3, 14)
    pic(s, "fig_pred_vs_actual.png", 6.9, 1.4, 6.1, 4.5)

    s = slide("Error analysis", "[1:30] Where do errors concentrate?")
    pic(s, "fig_error_by_soc_band.png", .4, 1.2, 6.2, 3.0)
    pic(s, "fig_feature_importance.png", 6.7, 1.2, 6.2, 3.0)
    pic(s, "fig_worst_file_trace.png", .4, 4.3, 12.5, 3.0)

    s = slide("Limitations and failure conditions", "[1:00] Be honest about the small held-out set and static framing.")
    bullets(s, [short(l, 175) for l in lim[:6]] or ["See docs/limitation_list.md"], .6, 1.3, 12.1, 5.8, 14)

    s = slide("Reproducible software package", "[1:00] Show the repository tree and one-line commands.")
    bullets(s, ["src/soc_pipeline: pipeline module + train / evaluate / predict command line", "models: frozen joblib pipelines + frozen_config.json + cross-validation results",
                "tests: pytest suite; outputs: example input -> output; figures + tables for every claim", "python scripts/predict.py --model-dir models --input in.csv --output out.csv",
                "Retraining from the frozen estimator + seed is checked against the stored model"], .6, 1.4, 12.1, 4.5, 15)

    s = slide("Future scope and conclusion", "[1:00] Close with the conclusion and invite questions.")
    bullets(s, [short(f, 140) for f in future[:5]] + ["Conclusion: " + short(conclusion, 200)], .6, 1.3, 12.1, 5.8, 14)
    prs.save(P("docs", "final_presentation.pptx"))
    print("wrote docs/final_presentation.pptx (%d slides)" % len(prs.slides))


if __name__ == "__main__":
    build_report()
    build_ppt()
