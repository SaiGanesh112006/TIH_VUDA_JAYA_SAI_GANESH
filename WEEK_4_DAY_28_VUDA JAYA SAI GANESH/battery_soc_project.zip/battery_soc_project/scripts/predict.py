"""Thin command-line wrapper: python scripts/predict.py <args>  (see --help)."""
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src"))
from soc_pipeline.core import main  # noqa: E402

if __name__ == "__main__":
    main(["predict"] + sys.argv[1:])
