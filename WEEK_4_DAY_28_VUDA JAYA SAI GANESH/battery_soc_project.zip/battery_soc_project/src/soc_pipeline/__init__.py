"""Frozen Li-ion battery SOC / remaining-charge-time pipeline."""
from .core import *  # noqa: F401,F403
from .core import main  # noqa: F401

__version__ = "1.0.0"
