"""Frozen Li-ion battery SOC / remaining-charge-time pipeline: inference, evaluation, retraining and command line."""
import argparse
import json
import os
import sys

import joblib
import numpy as np
import pandas as pd
from sklearn.base import clone
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

RAW_FEATURES = ["voltage_v", "current_a", "cell_temp_c", "power_w", "ambient_temp_c"]
TARGET = "soc_percent"
CHARGE_FEATURES = ["voltage_v", "current_a", "cell_temp_c", "ambient_temp_c"]
CHARGE_TARGET = "remaining_charge_time_s"
CONFIG_FILE = "frozen_config.json"
SOC_MODEL_FILE = "soc_final_pipeline.joblib"
CHARGE_MODEL_FILE = "charging_time_final_pipeline.joblib"

__all__ = ["RAW_FEATURES", "TARGET", "CHARGE_FEATURES", "CHARGE_TARGET", "load_config", "load_models", "predict_soc", "predict_charge",
           "metrics", "soc_report", "build_charge_frame", "evaluate", "retrain", "main"]


def check_columns(df, cols):
    missing = [c for c in cols if c not in df.columns]
    if missing:
        raise ValueError(f"Missing required input column(s): {missing}. Required: {cols}")


def load_config(model_dir):
    with open(os.path.join(model_dir, CONFIG_FILE)) as f:
        return json.load(f)


def load_models(model_dir):
    """Return (config, soc_model, charge_model); charge_model is None when it was not frozen."""
    cfg = load_config(model_dir)
    soc = joblib.load(os.path.join(model_dir, SOC_MODEL_FILE))
    cp = os.path.join(model_dir, CHARGE_MODEL_FILE)
    return cfg, soc, (joblib.load(cp) if os.path.exists(cp) else None)


def predict_soc(df, model):
    check_columns(df, RAW_FEATURES)
    return np.clip(model.predict(df[RAW_FEATURES]), 0, 100)


def predict_charge(df, model):
    check_columns(df, CHARGE_FEATURES)
    return np.clip(model.predict(df[CHARGE_FEATURES]), 0, None)


def metrics(y_true, y_pred):
    y_true, y_pred = np.asarray(y_true, float), np.asarray(y_pred, float)
    return {"MAE": float(mean_absolute_error(y_true, y_pred)), "RMSE": float(np.sqrt(mean_squared_error(y_true, y_pred))),
            "R2": float(r2_score(y_true, y_pred)) if len(y_true) > 1 else float("nan")}


def soc_report(df, model):
    """Held-out SOC metrics plus worst-file MAE and 95th-percentile absolute error."""
    check_columns(df, RAW_FEATURES + [TARGET, "file_id"])
    pred = predict_soc(df, model)
    err = np.abs(pred - df[TARGET].to_numpy(float))
    out = metrics(df[TARGET], pred)
    out.update(worst_file_MAE=float(pd.Series(err).groupby(df["file_id"].to_numpy()).mean().max()),
               p95_abs_error=float(np.percentile(err, 95)), n_rows=int(len(df)), n_files=int(df["file_id"].nunique()))
    return out


def build_charge_frame(full):
    """Rows with status CHA and their remaining time (s) to the end of the contiguous CHA segment (same recipe as Day 22)."""
    check_columns(full, ["file_id", "status", "prog_time"] + CHARGE_FEATURES)
    d = full.copy()
    d["prog_time_td"] = pd.to_timedelta(d["prog_time"], errors="coerce")
    d = d.sort_values(["file_id", "prog_time_td"]).reset_index(drop=True)
    d["status_change"] = (d["status"] != d["status"].shift(1)) | (d["file_id" ] != d["file_id"].shift(1))
    d["segment_id"] = d["status_change"].cumsum()
    c = d[d["status"] == "CHA"].copy()
    seg_end = c.groupby("segment_id")["prog_time_td"].transform("max")
    c[CHARGE_TARGET] = (seg_end - c["prog_time_td"]).dt.total_seconds()
    return c.dropna(subset=[CHARGE_TARGET] + CHARGE_FEATURES)


def evaluate(model_dir, test_csv, full_csv=None):
    cfg, soc_model, charge_model = load_models(model_dir)
    test = pd.read_csv(test_csv)
    out = {"soc": soc_report(test, soc_model), "charge": None}
    if charge_model is not None and full_csv and os.path.exists(full_csv):
        c = build_charge_frame(pd.read_csv(full_csv))
        c = c[c["file_id"].isin(test["file_id"].unique())]
        if len(c):
            out["charge"] = metrics(c[CHARGE_TARGET], predict_charge(c, charge_model))
            out["charge"].update(n_rows=int(len(c)), n_files=int(c["file_id"].nunique()))
    return out


def retrain(model_dir, train_csv, full_csv, out_dir):
    """Refit the frozen pipelines (same estimator + hyper-parameters + seed) on the frozen training files."""
    _, soc_model, charge_model = load_models(model_dir)
    train = pd.read_csv(train_csv)
    os.makedirs(out_dir, exist_ok=True)
    new_soc = clone(soc_model).fit(train[RAW_FEATURES], train[TARGET])
    joblib.dump(new_soc, os.path.join(out_dir, SOC_MODEL_FILE))
    new_charge = None
    if charge_model is not None and full_csv and os.path.exists(full_csv):
        c = build_charge_frame(pd.read_csv(full_csv))
        c = c[c["file_id"].isin(train["file_id"].unique())]
        if c["file_id"].nunique() >= 3:
            new_charge = clone(charge_model).fit(c[CHARGE_FEATURES], c[CHARGE_TARGET])
            joblib.dump(new_charge, os.path.join(out_dir, CHARGE_MODEL_FILE))
    return new_soc, new_charge


def main(argv=None):
    ap = argparse.ArgumentParser(prog="soc_pipeline", description="Frozen battery SOC / remaining-charge-time pipeline")
    ap.add_argument("command", choices=["predict", "evaluate", "train"])
    ap.add_argument("--model-dir", default="models", help="folder with the frozen .joblib files and frozen_config.json")
    ap.add_argument("--input", help="predict: CSV with the raw feature columns")
    ap.add_argument("--output", help="predict: output CSV; evaluate: metrics JSON")
    ap.add_argument("--test-csv", help="evaluate: held-out CSV (with soc_percent and file_id)")
    ap.add_argument("--train-csv", help="train: frozen training CSV")
    ap.add_argument("--full-csv", help="evaluate/train: full CSV with status and prog_time (needed for charge time)")
    ap.add_argument("--out-dir", default="retrained", help="train: where to write the refitted models")
    a = ap.parse_args(argv)
    if a.command == "predict":
        cfg, soc_model, charge_model = load_models(a.model_dir)
        df = pd.read_csv(a.input)
        df["pred_soc_percent"] = predict_soc(df, soc_model)
        if charge_model is not None and all(c in df.columns for c in CHARGE_FEATURES):
            df["pred_charge_time_s"] = predict_charge(df, charge_model)      # only meaningful during charging (status CHA)
        df.to_csv(a.output, index=False)
        print(f"wrote {a.output} ({len(df)} rows)")
    elif a.command == "evaluate":
        res = evaluate(a.model_dir, a.test_csv, a.full_csv)
        with open(a.output, "w") as f:
            json.dump(res, f, indent=2)
        print(json.dumps(res["soc"]))
    else:
        retrain(a.model_dir, a.train_csv, a.full_csv, a.out_dir)
        print("retrained models written to", a.out_dir)


if __name__ == "__main__":
    main()
