import json
import os
import subprocess
import sys

import numpy as np
import pandas as pd
import pytest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "src"))
from soc_pipeline import core as sp  # noqa: E402

MODEL_DIR = os.path.join(ROOT, "models")
SAMPLE = os.path.join(ROOT, "data", "sample_input.csv")
SAMPLE_TRUTH = os.path.join(ROOT, "data", "sample_with_truth.csv")


@pytest.fixture(scope="module")
def frozen():
    return sp.load_models(MODEL_DIR)


def test_config_is_complete(frozen):
    cfg = frozen[0]
    for key in ["chosen_model", "features", "target", "train_file_ids", "test_file_ids", "selection_rule", "versions"]:
        assert key in cfg
    assert cfg["features"] == sp.RAW_FEATURES and cfg["target"] == sp.TARGET


def test_split_files_are_disjoint(frozen):
    cfg = frozen[0]
    assert set(cfg["train_file_ids"]).isdisjoint(cfg["test_file_ids"])


def test_predictions_are_valid(frozen):
    df = pd.read_csv(SAMPLE)
    pred = sp.predict_soc(df, frozen[1])
    assert len(pred) == len(df) and np.isfinite(pred).all()
    assert pred.min() >= 0 and pred.max() <= 100


def test_predictions_are_deterministic(frozen):
    df = pd.read_csv(SAMPLE)
    assert np.allclose(sp.predict_soc(df, frozen[1]), sp.predict_soc(df, frozen[1]), atol=1e-8)


def test_missing_column_fails_loudly(frozen):
    df = pd.read_csv(SAMPLE).drop(columns=["voltage_v"])
    with pytest.raises(ValueError, match="voltage_v"):
        sp.predict_soc(df, frozen[1])


def test_sample_metrics_match_recorded_values(frozen):
    truth = pd.read_csv(SAMPLE_TRUTH)
    m = sp.metrics(truth[sp.TARGET], sp.predict_soc(truth, frozen[1]))
    rec = json.load(open(os.path.join(ROOT, "outputs", "sample_metrics.json")))
    assert abs(m["MAE"] - rec["MAE"]) < 1e-9


def test_command_line_roundtrip(tmp_path):
    out = tmp_path / "out.csv"
    r = subprocess.run([sys.executable, os.path.join(ROOT, "scripts", "predict.py"), "--model-dir", MODEL_DIR,
                        "--input", SAMPLE, "--output", str(out)], capture_output=True, text=True)
    assert r.returncode == 0, r.stderr
    o = pd.read_csv(out)
    assert "pred_soc_percent" in o.columns and len(o) == len(pd.read_csv(SAMPLE))
