# Limitations and likely failure conditions

1. **Small held-out set** - only 5 files / 328 rows, so every metric has wide uncertainty.
2. **Uneven error across SOC** - the highest MAE is in the 0-10 % band (74.33 % vs overall 27.73 %).
3. **Occasional large errors** - RMSE (37.71 %) is 1.4x the MAE; the worst file has MAE 35.74 %.
4. **Robustness flag from Day 22** - the worst cross-validation fold MAE exceeded 2x the mean fold MAE, so accuracy varies strongly between files.
5. **Limited operating conditions** - ambient temperature in the data: 25 C; other temperatures are untested.
6. **Static framing** - each row is predicted independently (no history), so sensor noise or drift is not filtered.
7. **Charge-time model is low confidence** - evaluated on only 5 file(s).
8. **Noted on Day 22** - low-SOC knee errors; only 25 degC data; RMSE >> MAE means occasional large mistakes.
